/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Mar 8, 2018 12:25:09 PM                     ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2016 SAP SE
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of SAP
 * Hybris ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with SAP Hybris.
 *  
 */
package de.hybris.training.core.jalo;

import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloInvalidParameterException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.C2LManager;
import de.hybris.platform.jalo.c2l.Language;
import de.hybris.platform.jalo.media.Media;
import de.hybris.platform.jalo.product.Product;
import de.hybris.training.core.constants.TrainingCoreConstants;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.training.core.jalo.DummyPage DummyPage}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedDummyPage extends Product
{
	/** Qualifier of the <code>DummyPage.data</code> attribute **/
	public static final String DATA = "data";
	/** Qualifier of the <code>DummyPage.image</code> attribute **/
	public static final String IMAGE = "image";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(Product.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(DATA, AttributeMode.INITIAL);
		tmp.put(IMAGE, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>DummyPage.data</code> attribute.
	 * @return the data
	 */
	public String getData(final SessionContext ctx)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedDummyPage.getData requires a session language", 0 );
		}
		return (String)getLocalizedProperty( ctx, DATA);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>DummyPage.data</code> attribute.
	 * @return the data
	 */
	public String getData()
	{
		return getData( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>DummyPage.data</code> attribute. 
	 * @return the localized data
	 */
	public Map<Language,String> getAllData(final SessionContext ctx)
	{
		return (Map<Language,String>)getAllLocalizedProperties(ctx,DATA,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>DummyPage.data</code> attribute. 
	 * @return the localized data
	 */
	public Map<Language,String> getAllData()
	{
		return getAllData( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>DummyPage.data</code> attribute. 
	 * @param value the data
	 */
	public void setData(final SessionContext ctx, final String value)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedDummyPage.setData requires a session language", 0 );
		}
		setLocalizedProperty(ctx, DATA,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>DummyPage.data</code> attribute. 
	 * @param value the data
	 */
	public void setData(final String value)
	{
		setData( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>DummyPage.data</code> attribute. 
	 * @param value the data
	 */
	public void setAllData(final SessionContext ctx, final Map<Language,String> value)
	{
		setAllLocalizedProperties(ctx,DATA,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>DummyPage.data</code> attribute. 
	 * @param value the data
	 */
	public void setAllData(final Map<Language,String> value)
	{
		setAllData( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>DummyPage.image</code> attribute.
	 * @return the image
	 */
	public Media getImage(final SessionContext ctx)
	{
		return (Media)getProperty( ctx, IMAGE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>DummyPage.image</code> attribute.
	 * @return the image
	 */
	public Media getImage()
	{
		return getImage( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>DummyPage.image</code> attribute. 
	 * @param value the image
	 */
	public void setImage(final SessionContext ctx, final Media value)
	{
		setProperty(ctx, IMAGE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>DummyPage.image</code> attribute. 
	 * @param value the image
	 */
	public void setImage(final Media value)
	{
		setImage( getSession().getSessionContext(), value );
	}
	
}
