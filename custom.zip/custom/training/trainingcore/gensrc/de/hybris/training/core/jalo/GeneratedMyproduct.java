/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Mar 8, 2018 12:25:09 PM                     ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 *  
 * Copyright (c) 2000-2016 SAP SE
 * All rights reserved.
 *  
 * This software is the confidential and proprietary information of SAP
 * Hybris ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with SAP Hybris.
 *  
 */
package de.hybris.training.core.jalo;

import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloInvalidParameterException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.C2LManager;
import de.hybris.platform.jalo.c2l.Language;
import de.hybris.platform.jalo.product.Product;
import de.hybris.training.core.constants.TrainingCoreConstants;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.training.core.jalo.Myproduct Myproduct}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedMyproduct extends Product
{
	/** Qualifier of the <code>Myproduct.include</code> attribute **/
	public static final String INCLUDE = "include";
	/** Qualifier of the <code>Myproduct.exclude</code> attribute **/
	public static final String EXCLUDE = "exclude";
	/** Qualifier of the <code>Myproduct.employee</code> attribute **/
	public static final String EMPLOYEE = "employee";
	/** Qualifier of the <code>Myproduct.empDescription</code> attribute **/
	public static final String EMPDESCRIPTION = "empDescription";
	/** Qualifier of the <code>Myproduct.age</code> attribute **/
	public static final String AGE = "age";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(Product.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(INCLUDE, AttributeMode.INITIAL);
		tmp.put(EXCLUDE, AttributeMode.INITIAL);
		tmp.put(EMPLOYEE, AttributeMode.INITIAL);
		tmp.put(EMPDESCRIPTION, AttributeMode.INITIAL);
		tmp.put(AGE, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.age</code> attribute.
	 * @return the age
	 */
	public Integer getAge(final SessionContext ctx)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.getAge requires a session language", 0 );
		}
		return (Integer)getLocalizedProperty( ctx, AGE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.age</code> attribute.
	 * @return the age
	 */
	public Integer getAge()
	{
		return getAge( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.age</code> attribute. 
	 * @return the age
	 */
	public int getAgeAsPrimitive(final SessionContext ctx)
	{
		Integer value = getAge( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.age</code> attribute. 
	 * @return the age
	 */
	public int getAgeAsPrimitive()
	{
		return getAgeAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.age</code> attribute. 
	 * @return the localized age
	 */
	public Map<Language,Integer> getAllAge(final SessionContext ctx)
	{
		return (Map<Language,Integer>)getAllLocalizedProperties(ctx,AGE,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.age</code> attribute. 
	 * @return the localized age
	 */
	public Map<Language,Integer> getAllAge()
	{
		return getAllAge( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.age</code> attribute. 
	 * @param value the age
	 */
	public void setAge(final SessionContext ctx, final Integer value)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.setAge requires a session language", 0 );
		}
		setLocalizedProperty(ctx, AGE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.age</code> attribute. 
	 * @param value the age
	 */
	public void setAge(final Integer value)
	{
		setAge( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.age</code> attribute. 
	 * @param value the age
	 */
	public void setAge(final SessionContext ctx, final int value)
	{
		setAge( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.age</code> attribute. 
	 * @param value the age
	 */
	public void setAge(final int value)
	{
		setAge( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.age</code> attribute. 
	 * @param value the age
	 */
	public void setAllAge(final SessionContext ctx, final Map<Language,Integer> value)
	{
		setAllLocalizedProperties(ctx,AGE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.age</code> attribute. 
	 * @param value the age
	 */
	public void setAllAge(final Map<Language,Integer> value)
	{
		setAllAge( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.empDescription</code> attribute.
	 * @return the empDescription
	 */
	public String getEmpDescription(final SessionContext ctx)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.getEmpDescription requires a session language", 0 );
		}
		return (String)getLocalizedProperty( ctx, EMPDESCRIPTION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.empDescription</code> attribute.
	 * @return the empDescription
	 */
	public String getEmpDescription()
	{
		return getEmpDescription( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.empDescription</code> attribute. 
	 * @return the localized empDescription
	 */
	public Map<Language,String> getAllEmpDescription(final SessionContext ctx)
	{
		return (Map<Language,String>)getAllLocalizedProperties(ctx,EMPDESCRIPTION,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.empDescription</code> attribute. 
	 * @return the localized empDescription
	 */
	public Map<Language,String> getAllEmpDescription()
	{
		return getAllEmpDescription( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.empDescription</code> attribute. 
	 * @param value the empDescription
	 */
	public void setEmpDescription(final SessionContext ctx, final String value)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.setEmpDescription requires a session language", 0 );
		}
		setLocalizedProperty(ctx, EMPDESCRIPTION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.empDescription</code> attribute. 
	 * @param value the empDescription
	 */
	public void setEmpDescription(final String value)
	{
		setEmpDescription( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.empDescription</code> attribute. 
	 * @param value the empDescription
	 */
	public void setAllEmpDescription(final SessionContext ctx, final Map<Language,String> value)
	{
		setAllLocalizedProperties(ctx,EMPDESCRIPTION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.empDescription</code> attribute. 
	 * @param value the empDescription
	 */
	public void setAllEmpDescription(final Map<Language,String> value)
	{
		setAllEmpDescription( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.employee</code> attribute.
	 * @return the employee
	 */
	public String getEmployee(final SessionContext ctx)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.getEmployee requires a session language", 0 );
		}
		return (String)getLocalizedProperty( ctx, EMPLOYEE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.employee</code> attribute.
	 * @return the employee
	 */
	public String getEmployee()
	{
		return getEmployee( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.employee</code> attribute. 
	 * @return the localized employee
	 */
	public Map<Language,String> getAllEmployee(final SessionContext ctx)
	{
		return (Map<Language,String>)getAllLocalizedProperties(ctx,EMPLOYEE,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.employee</code> attribute. 
	 * @return the localized employee
	 */
	public Map<Language,String> getAllEmployee()
	{
		return getAllEmployee( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.employee</code> attribute. 
	 * @param value the employee
	 */
	public void setEmployee(final SessionContext ctx, final String value)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.setEmployee requires a session language", 0 );
		}
		setLocalizedProperty(ctx, EMPLOYEE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.employee</code> attribute. 
	 * @param value the employee
	 */
	public void setEmployee(final String value)
	{
		setEmployee( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.employee</code> attribute. 
	 * @param value the employee
	 */
	public void setAllEmployee(final SessionContext ctx, final Map<Language,String> value)
	{
		setAllLocalizedProperties(ctx,EMPLOYEE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.employee</code> attribute. 
	 * @param value the employee
	 */
	public void setAllEmployee(final Map<Language,String> value)
	{
		setAllEmployee( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.exclude</code> attribute.
	 * @return the exclude
	 */
	public String getExclude(final SessionContext ctx)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.getExclude requires a session language", 0 );
		}
		return (String)getLocalizedProperty( ctx, EXCLUDE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.exclude</code> attribute.
	 * @return the exclude
	 */
	public String getExclude()
	{
		return getExclude( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.exclude</code> attribute. 
	 * @return the localized exclude
	 */
	public Map<Language,String> getAllExclude(final SessionContext ctx)
	{
		return (Map<Language,String>)getAllLocalizedProperties(ctx,EXCLUDE,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.exclude</code> attribute. 
	 * @return the localized exclude
	 */
	public Map<Language,String> getAllExclude()
	{
		return getAllExclude( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.exclude</code> attribute. 
	 * @param value the exclude
	 */
	public void setExclude(final SessionContext ctx, final String value)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.setExclude requires a session language", 0 );
		}
		setLocalizedProperty(ctx, EXCLUDE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.exclude</code> attribute. 
	 * @param value the exclude
	 */
	public void setExclude(final String value)
	{
		setExclude( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.exclude</code> attribute. 
	 * @param value the exclude
	 */
	public void setAllExclude(final SessionContext ctx, final Map<Language,String> value)
	{
		setAllLocalizedProperties(ctx,EXCLUDE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.exclude</code> attribute. 
	 * @param value the exclude
	 */
	public void setAllExclude(final Map<Language,String> value)
	{
		setAllExclude( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.include</code> attribute.
	 * @return the include
	 */
	public String getInclude(final SessionContext ctx)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.getInclude requires a session language", 0 );
		}
		return (String)getLocalizedProperty( ctx, INCLUDE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.include</code> attribute.
	 * @return the include
	 */
	public String getInclude()
	{
		return getInclude( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.include</code> attribute. 
	 * @return the localized include
	 */
	public Map<Language,String> getAllInclude(final SessionContext ctx)
	{
		return (Map<Language,String>)getAllLocalizedProperties(ctx,INCLUDE,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Myproduct.include</code> attribute. 
	 * @return the localized include
	 */
	public Map<Language,String> getAllInclude()
	{
		return getAllInclude( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.include</code> attribute. 
	 * @param value the include
	 */
	public void setInclude(final SessionContext ctx, final String value)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedMyproduct.setInclude requires a session language", 0 );
		}
		setLocalizedProperty(ctx, INCLUDE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.include</code> attribute. 
	 * @param value the include
	 */
	public void setInclude(final String value)
	{
		setInclude( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.include</code> attribute. 
	 * @param value the include
	 */
	public void setAllInclude(final SessionContext ctx, final Map<Language,String> value)
	{
		setAllLocalizedProperties(ctx,INCLUDE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Myproduct.include</code> attribute. 
	 * @param value the include
	 */
	public void setAllInclude(final Map<Language,String> value)
	{
		setAllInclude( getSession().getSessionContext(), value );
	}
	
}
