
put your configuration files here.
(local.properties, localextensions.xml)
